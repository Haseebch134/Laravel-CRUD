
<!doctype html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Laravel</title>
</head>

<body>
<h1>DATA</h1>
<p>This is the Insert page.</p>

@if(count($posts) > 0)
    @foreach($posts as $post)
        <div class="well">
        	<h3><a href="/posts/{{$post->id}}">{{$post->title}}</a></h3>
    @endforeach    	
@else
    <p>No Data Found</p>
@endif

        </div>



</body>

</html>

