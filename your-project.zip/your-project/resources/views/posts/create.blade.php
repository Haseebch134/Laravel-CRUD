
<!doctype html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Laravel</title>
</head>

<body>
<h1>Create Post</h1>
{!! Form::open(['action' => 'PostsController@store', 'method' => 'POST','enctype' => 'multipart/form-data']) !!}
    <div class="form-group">
        {{Form::label('title', 'Title')}}
        {{Form::text('title','', ['class' => 'form-control','placeholder' => 'Title'])}}
    </div>
    <div><br></div>

<!-- //*************************************************** -->

    <div class="form-group">
        {{Form::label('body', 'Body')}}
        {{Form::textarea('body','', ['id' => 'article-ckeditor','class' => 'form-control','placeholder' => 'Body'])}}
    </div>

<div><br></div>
     {{Form::submit('Submit', ['class' => 'btn btn-primary'])}}

{!! Form::close() !!}


</body>

</html>

