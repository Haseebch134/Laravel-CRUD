
<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Laravel</title>
</head>

<body>
<h1>DATA</h1>
<p>This is the Insert page.</p>

<?php if(count($posts) > 0): ?>
    <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="well">
        	<h3><a href="/posts/<?php echo e($post->id); ?>"><?php echo e($post->title); ?></a></h3>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>    	
<?php else: ?>
    <p>No Data Found</p>
<?php endif; ?>

        </div>



</body>

</html>

<?php /**PATH /var/www/html/your-project/resources/views/posts/index.blade.php ENDPATH**/ ?>