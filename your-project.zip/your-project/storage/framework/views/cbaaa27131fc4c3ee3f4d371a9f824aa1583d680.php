
<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Laravel</title>
</head>

<body>
<h1>Create Post</h1>
<?php echo Form::open(['action' => 'PostsController@store', 'method' => 'POST','enctype' => 'multipart/form-data']); ?>

    <div class="form-group">
        <?php echo e(Form::label('title', 'Title')); ?>

        <?php echo e(Form::text('title','', ['class' => 'form-control','placeholder' => 'Title'])); ?>

    </div>
    <div><br></div>

<!-- //*************************************************** -->

    <div class="form-group">
        <?php echo e(Form::label('body', 'Body')); ?>

        <?php echo e(Form::textarea('body','', ['id' => 'article-ckeditor','class' => 'form-control','placeholder' => 'Body'])); ?>

    </div>

<div><br></div>
     <?php echo e(Form::submit('Submit', ['class' => 'btn btn-primary'])); ?>


<?php echo Form::close(); ?>



</body>

</html>

<?php /**PATH /var/www/html/your-project/resources/views/posts/create.blade.php ENDPATH**/ ?>